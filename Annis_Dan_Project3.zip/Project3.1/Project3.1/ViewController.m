//
//  ViewController.m
//  Project3.1
//
//  Created by Annis Dan on 4/19/12.
//  Copyright (c) 2012 Dannis. All rights reserved.
//

#import "ViewController.h"
#include "UICustomColors.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewWillAppear:(BOOL)animated
{
    
// SETTING BACKGROUND COLOR
    self.view.backgroundColor=[UIColor blackColor];
    
// LABEL FOR MY INFORMATION
    projectInfo = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, 395.0f, 300.0f,50.0f)];
    [self.view addSubview:projectInfo];
    
    [super viewWillAppear:animated];
    
}



-(void)viewDidAppear:(BOOL)animated
{

// ADDING IN SOME PROJECT INFORMATION    
    projectInfo.text=@"Dan Annis - 4/19/2012 - Project 3";
    projectInfo.textAlignment=UITextAlignmentCenter;
    projectInfo.backgroundColor=[UIColor myBlue];
    projectInfo.textColor= [UIColor whiteColor];
    [super viewDidAppear:animated];

//THE CALLS FOR THE FUNCTIONS/METHODS/DO STUFF THINGYS
    
    //ADD
    NSInteger addition = [self add:10 to:20];
    NSNumber *numberSum = [[NSNumber alloc] initWithInt:addition];
    NSString *theNumTxt = [NSString stringWithFormat:@"The sum of the numbers are... "];
    NSString *numberToString = [numberSum stringValue];
    NSString *myNumAddString = [self append:theNumTxt to:numberToString];
    [self displayAlertWithString:myNumAddString];
    
    
    //COMPARE
    NSInteger num1 = 10;
    NSInteger num2 = 20;
    BOOL compareNum = [self compare:num1 to:num2];
    NSString *myCompareString = [NSString stringWithFormat:@"Is %d and %d equal to each other? %@", num1, num2, compareNum?@"TRUE":@"FALSE"];
    [self displayAlertWithString:myCompareString];
    
    //APPEND
    NSString *myAppendString = [self append:@"I still feel like... " to:@"I have no Idea what I am doing!"];
    [self displayAlertWithString:myAppendString];
    
   
}


//MY FUNCTIONS OR METHODS OR DO STUFF THINGYS

//ADD
-(NSInteger)add:(NSInteger)num1 to:(NSInteger)num2{
    return num1 + num2;
}

//COMPARE
-(BOOL)compare:(NSInteger)num1 to:(NSInteger)num2{
    if (num1 == num2) {
        return YES;
    }else{
        return NO;
    }
}

//APPEND
-(NSString *)append:(NSString *)string1 to:(NSString *)string2{
    NSMutableString *appendedString = [NSMutableString stringWithString:string1];
    NSString *string = [appendedString stringByAppendingString:string2];
    return string;
}

//UIAlertView
-(void)displayAlertWithString:(NSString *)string{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"WHAT ARE YOU DOING?" message:string delegate:nil cancelButtonTitle:@"< SMACK HEAD >" otherButtonTitles:nil, nil];
    [alert show];
}



- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
