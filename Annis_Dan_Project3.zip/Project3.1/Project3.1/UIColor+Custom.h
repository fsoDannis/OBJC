@interface UIColor (Custom)

+ (UIColor *)myRed;
+ (UIColor *)mylightRed;
+ (UIColor *)myOrange;
+ (UIColor *)mylightOrange;
+ (UIColor *)myYellow;
+ (UIColor *)mylightYellow;
+ (UIColor *)myGreen;
+ (UIColor *)mylightGreen;
+ (UIColor *)myBlue;
+ (UIColor *)mylightBlue;
+ (UIColor *)myIndigo;
+ (UIColor *)mylightIndigo;
+ (UIColor *)myViolet;
+ (UIColor *)mylightViolet;

@end
