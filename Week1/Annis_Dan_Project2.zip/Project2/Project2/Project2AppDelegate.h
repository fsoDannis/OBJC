//
//  Project2AppDelegate.h
//  Project2
//
//  Created by Annis Dan on 4/5/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Project2ViewController;

@interface Project2AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Project2ViewController *viewController;

@end
