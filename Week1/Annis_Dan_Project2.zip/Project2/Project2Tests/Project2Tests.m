//
//  Project2Tests.m
//  Project2Tests
//
//  Created by Annis Dan on 4/5/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "Project2Tests.h"

@implementation Project2Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Project2Tests");
}

@end
