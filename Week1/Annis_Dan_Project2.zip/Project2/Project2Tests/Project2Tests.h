//
//  Project2Tests.h
//  Project2Tests
//
//  Created by Annis Dan on 4/5/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface Project2Tests : SenTestCase

@end
