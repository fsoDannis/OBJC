//
//  Project1Tests.m
//  Project1Tests
//
//  Created by Annis Dan on 3/29/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "Project1Tests.h"

@implementation Project1Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Project1Tests");
}

@end
