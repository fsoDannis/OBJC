//
//  Project1Tests.h
//  Project1Tests
//
//  Created by Annis Dan on 3/29/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface Project1Tests : SenTestCase

@end
