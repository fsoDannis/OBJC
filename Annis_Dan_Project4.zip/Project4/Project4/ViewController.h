//
//  ViewController.h
//  Project4
//
//  Created by Annis Dan on 4/23/12.
//  Copyright (c) 2012 Dannis Designs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    UILabel *username;
    UILabel *dateLabel;
    UITextField *inputUsername;
   
    UILabel *loginInfo;
    UILabel *projectInfo;
}


@end
